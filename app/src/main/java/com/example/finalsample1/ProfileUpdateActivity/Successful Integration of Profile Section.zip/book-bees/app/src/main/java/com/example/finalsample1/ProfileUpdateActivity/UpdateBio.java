package com.example.finalsample1.ProfileUpdateActivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.finalsample1.R;

public class UpdateBio extends AppCompatActivity {
//    EditText bio_input = findViewById(R.id.et_bio);
//    Button save = findViewById(R.id.btn_save);
//    Button cancel = findViewById(R.id.btn_cancel);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_bio_edit);
    }

}
