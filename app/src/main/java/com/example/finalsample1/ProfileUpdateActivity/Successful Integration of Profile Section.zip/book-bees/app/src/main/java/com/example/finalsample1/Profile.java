package com.example.finalsample1;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.finalsample1.ProfileUpdateActivity.UpdateBio;
import com.example.finalsample1.ProfileUpdateActivity.UpdateGenre;
import com.example.finalsample1.R;

import java.util.Objects;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

public class Profile extends Fragment {
    private static final String TAG = "ProfileFragment";
    private ImageView profile_picture, edit_bio, edit_genre;
    private static final int image_picker=1;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        profile_picture = view.findViewById(R.id.profile_picture);
        edit_bio = view.findViewById(R.id.iv_bio_edit);
        edit_genre = view.findViewById(R.id.iv_genres_edit);

        edit_bio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit_bio_click();
            }
        });

        edit_genre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit_genre_click();
            }
        });

        profile_picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateImage(getContext());
            }
        });
        return view;
    }

    private void edit_genre_click() {
        Intent intentMain = new Intent(getActivity(), UpdateGenre.class);
        startActivity(intentMain);
    }

    private void edit_bio_click() {
        Intent intentMain = new Intent(getActivity(), UpdateBio.class);
        startActivity(intentMain);
    }


    private void updateImage(Context context) {
        final CharSequence[] options = { "Open Camera", "Choose from Gallery","Cancel" };

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Your Profile Picture");
        builder.setItems(options, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Open Camera")) {
                    Intent clickPicture = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(clickPicture, 0);

                } else if (options[item].equals("Choose from Gallery")) {
                    Intent choosePicture = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(choosePicture , 1);

                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 0:
                    if (resultCode == RESULT_OK && data != null) {
                        Bitmap clickedImage = (Bitmap) data.getExtras().get("data");
                        profile_picture.setImageBitmap(clickedImage);
                    }

                    break;
                case 1:
                    if (resultCode == RESULT_OK && data != null) {
                        Uri selectedImage = data.getData();
                        profile_picture.setImageURI(selectedImage);
                    }
                    break;
            }
        }
    }
}
